<?php
class BeforeValidException extends \UnexpectedValueException
{

}
