<?php defined('BASEPATH') or exit('No direct script access allowed');

class Users_model  extends CI_Model
{

    public function __construct()
    {
        parent::__construct();

        $this->load->database();
    }

    public function logingroupuser($user){
        $query =  $this->db->query("SELECT * from users ");
        return $query->num_rows();
    }

  


    
   
}

