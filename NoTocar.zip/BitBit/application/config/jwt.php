<?php
 defined('BASEPATH') OR exit('No direct script access allowed');

$config['jwt_key'] = 'supersecret';
//$config['jwt_key'] = 'l6ucUSL2dubJ2jDBgtm7y1WjlpuKoTPOkIAyFFSlQTDsP8nnS18DgpuCPskgFUEe';

$config['jwt_autorenew'] = TRUE;
$config['jwt_timeout'] = 300;

$config['jwt_table'] = 'tokens';
                      
