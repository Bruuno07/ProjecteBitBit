
<head>
    <title>Inicio</title>
</head>
<!-- 
<?php
if ($this->session->flashdata('access')) {
?>
    <div class="alert alert-danger" style="margin-top: 120px;">
        <?php echo $this->session->flashdata('access'); ?>
    </div>
<?php } 
 unset($_SESSION['access']);
?> -->




<section>
    <div class="flex-container">

        <div class="row">
            <div class="col-2 margenes">
                1 of 3
            </div>
            <div class="col-8 ">
                2 of 3
            </div>
            <div class="col-2 margenes">
                3 of 3
            </div>
        </div>
    </div>

    </div>
</section>