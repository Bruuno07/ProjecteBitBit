
<head>
    <title>Inicio</title>
</head>

<section>
    <div class="home-slider owl-carousel js-fullheight">
        <div class="slider-item js-fullheight" style="background-image:url(<?php echo base_url("assets/img/car1.png"); ?>);">
            <div class="overlay"></div>
            <div class="container justify-content-center ">
                <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
                    <div class="col-md-12 ftco-animate text-center justify-content-center align-items-center ">
                        <div class="text w-100">
                            <h1 class="mb-3">Reparación</h1>
                            <h2>De equipos y dispositivos</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="slider-item js-fullheight" style="background-image:url(<?php echo base_url("assets/img/car2.jpg"); ?>);">
            <div class="overlay"></div>
            <div class="container justify-content-center">
                <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
                    <div class="col-md-12 ftco-animate ">
                        <div class="text w-100 text-center">
                            <h1 class="mb-3">A tu Alcance</h1>
                            <h2>Cerca de ti</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="slider-item js-fullheight" style="background-image:url(<?php echo base_url("assets/img/car3.jpg"); ?>);">
            <div class="overlay"></div>
            <div class="container justify-content-center">
                <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
                    <div class="col-md-12 ftco-animate">
                        <div class="text w-100 text-center">
                            <h1 class="mb-3">Confianza</h1>
                            <h2>Y respaldo</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<section>
    <div class="flex-container">

        <div class="row">
            <div class="col-2 margenes">
                1 of 3
            </div>
            <div class="col-8 ">
                2 of 3
            </div>
            <div class="col-2 margenes">
                3 of 3
            </div>
        </div>
    </div>

    </div>
</section>