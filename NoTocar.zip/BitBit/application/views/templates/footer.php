<!-- ini del footer.php -->
<script src="<?php echo base_url("assets/js/owl.carousel.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/main.js"); ?>"></script>

        </body>
</html>